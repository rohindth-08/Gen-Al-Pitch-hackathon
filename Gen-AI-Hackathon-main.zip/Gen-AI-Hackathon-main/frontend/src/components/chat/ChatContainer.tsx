const ChatContainer = () => {
  return <div>ChatContainer</div>;
};

export default ChatContainer;
