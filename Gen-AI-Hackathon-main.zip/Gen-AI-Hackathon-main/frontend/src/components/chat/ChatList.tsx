const ChatList = () => {
  return <div>ChatList</div>;
};

export default ChatList;
