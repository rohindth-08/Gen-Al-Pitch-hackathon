"use client";
import { useState } from "react";

type StoredValue<T> = [T, (value: T) => void, () => void];

function useLocalStorage<T>(key: string, initialValue: T): StoredValue<T> {
  const readValue = (): T => {
    if (typeof window === "undefined") {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key “${key}”:`, error);
      return initialValue;
    }
  };

  const [storedValue, setStoredValue] = useState(readValue);

  const setValue = (value: T) => {
    if (typeof window == "undefined") {
      console.warn(
        `Tried setting localStorage key “${key}” even though environment is not a client`
      );
    }
    try {
      const newValue = value instanceof Function ? value(storedValue) : value;
      window.localStorage.setItem(key, JSON.stringify(newValue));
      setStoredValue(newValue);
      window.dispatchEvent(new Event("local-storage"));
    } catch (error) {
      console.warn(`Error setting localStorage key “${key}”:`, error);
    }
  };

  const removeValue = () => {
    if (typeof window == "undefined") {
      console.warn(
        `Tried removing localStorage key “${key}” even though environment is not a client`
      );
    }
    try {
      window.localStorage.removeItem(key);
      window.dispatchEvent(new Event("local-storage"));
    } catch (error) {
      console.warn(`Error removing localStorage key “${key}”:`, error);
    }
  };
  return [storedValue, setValue, removeValue];
}

export default useLocalStorage;
